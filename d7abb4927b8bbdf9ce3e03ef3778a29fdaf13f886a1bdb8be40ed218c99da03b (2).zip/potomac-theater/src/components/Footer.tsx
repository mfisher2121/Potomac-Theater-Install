import React from 'react';
import { Phone, Mail, MapPin, Award, Star } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="luxury-bg text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="text-2xl font-bold tracking-wide mb-4">
              <span className="text-white">Potomac</span>
              <span className="luxury-accent ml-2">Theater Installers</span>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed max-w-md">
              Licensed professionals creating extraordinary home theater experiences 
              for discerning Potomac homeowners since 2009.
            </p>
            
            {/* Certifications */}
            <div className="flex flex-wrap gap-3 mb-6">
              <span className="bg-gray-800 luxury-accent px-3 py-1 rounded text-sm font-medium">THX Certified</span>
              <span className="bg-gray-800 luxury-accent px-3 py-1 rounded text-sm font-medium">CEDIA Member</span>
              <span className="bg-gray-800 luxury-accent px-3 py-1 rounded text-sm font-medium">Licensed & Insured</span>
            </div>
            
            {/* Rating */}
            <div className="flex items-center space-x-2">
              <div className="flex space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-orange-400 text-orange-400" />
                ))}
              </div>
              <span className="text-gray-400 text-sm">4.9/5 from 127+ reviews</span>
            </div>
          </div>
          
          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4 luxury-accent">Services</h3>
            <ul className="space-y-3 text-gray-400">
              <li><a href="#services" className="hover:text-orange-400 transition-colors duration-300">Basement Conversion</a></li>
              <li><a href="#services" className="hover:text-orange-400 transition-colors duration-300">Projector Installation</a></li>
              <li><a href="#services" className="hover:text-orange-400 transition-colors duration-300">Surround & Atmos</a></li>
              <li><a href="#services" className="hover:text-orange-400 transition-colors duration-300">Smart Home Integration</a></li>
              <li><a href="#services" className="hover:text-orange-400 transition-colors duration-300">Acoustic Treatment</a></li>
              <li><a href="#services" className="hover:text-orange-400 transition-colors duration-300">Custom Seating</a></li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4 luxury-accent">Contact</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-orange-400" />
                <span className="text-gray-400">(301) 555-0123</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-orange-400" />
                <span className="text-gray-400">info@potomactheater.com</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="w-4 h-4 text-orange-400 mt-1" />
                <div className="text-gray-400">
                  <div>Potomac, MD</div>
                  <div className="text-sm">Serving Greater DC Metro</div>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <h4 className="font-semibold text-white mb-2">Business Hours</h4>
              <div className="text-sm text-gray-400 space-y-1">
                <div>Mon-Fri: 8:00 AM - 6:00 PM</div>
                <div>Saturday: 9:00 AM - 4:00 PM</div>
                <div>Sunday: By Appointment</div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Service Areas */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="text-center mb-6">
            <h4 className="text-lg font-semibold mb-4 luxury-accent">Service Areas</h4>
            <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-400">
              <span>Potomac</span>
              <span>•</span>
              <span>Bethesda</span>
              <span>•</span>
              <span>McLean</span>
              <span>•</span>
              <span>Great Falls</span>
              <span>•</span>
              <span>Rockville</span>
              <span>•</span>
              <span>Arlington</span>
              <span>•</span>
              <span>Alexandria</span>
            </div>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
          <p>&copy; {currentYear} Potomac Theater Installers. All rights reserved.</p>
          <div className="flex justify-center space-x-6 mt-4 text-sm">
            <a href="#" className="hover:text-orange-400 transition-colors duration-300">Privacy Policy</a>
            <a href="#" className="hover:text-orange-400 transition-colors duration-300">Terms of Service</a>
            <a href="#" className="hover:text-orange-400 transition-colors duration-300">License Info</a>
          </div>
          <p className="text-xs mt-4 text-gray-500">
            Licensed Home Theater Installer • Maryland License #12345 • Insured & Bonded
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;