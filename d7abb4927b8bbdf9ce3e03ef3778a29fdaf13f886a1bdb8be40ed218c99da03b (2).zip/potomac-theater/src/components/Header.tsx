import React from 'react';
import { Phone, Mail } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-black/95 backdrop-blur-sm text-white sticky top-0 z-50 border-b border-gray-800">
      <div className="container mx-auto px-4">
        {/* Top contact bar */}
        <div className="hidden md:flex justify-end py-2 text-sm border-b border-gray-800">
          <div className="flex items-center space-x-6">
            <a href="tel:+1234567890" className="flex items-center space-x-2 hover:text-orange-400 transition-colors">
              <Phone size={14} />
              <span>(301) 555-0123</span>
            </a>
            <a href="mailto:info@potomactheater.com" className="flex items-center space-x-2 hover:text-orange-400 transition-colors">
              <Mail size={14} />
              <span>info@potomactheater.com</span>
            </a>
          </div>
        </div>
        
        {/* Main navigation */}
        <div className="flex justify-between items-center py-4">
          <div className="text-xl font-bold tracking-wide">
            <span className="text-white">Potomac</span>
            <span className="luxury-accent ml-2">Theater Installers</span>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="hover:text-orange-400 transition-colors duration-300 font-medium">Home</a>
            <a href="#services" className="hover:text-orange-400 transition-colors duration-300 font-medium">Services</a>
            <a href="#guide" className="hover:text-orange-400 transition-colors duration-300 font-medium">Free Guide</a>
            <a href="#contact" className="hover:text-orange-400 transition-colors duration-300 font-medium">Contact</a>
          </nav>
          
          {/* CTA Button */}
          <div className="hidden lg:block">
            <a 
              href="#contact" 
              className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Free Consultation
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;