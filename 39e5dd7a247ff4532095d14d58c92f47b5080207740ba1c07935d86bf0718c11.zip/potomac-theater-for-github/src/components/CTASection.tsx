import React from 'react';
import { Phone, Mail, Calendar, Award } from 'lucide-react';

const CTASection = () => {
  return (
    <section id="contact" className="relative py-20 overflow-hidden">
      {/* Background Image with Blur */}
      <div className="absolute inset-0">
        <picture>
          <source
            srcSet="/images/cta_bg.avif"
            type="image/avif"
          />
          <img
            src="/images/cta_bg.webp"
            alt="Luxury cinema background"
            className="w-full h-full object-cover"
          />
        </picture>
        {/* Blurred overlay */}
        <div className="absolute inset-0 bg-black/60 blur-strong"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/60"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-5xl mx-auto text-center text-white">
          {/* Trust Indicators */}
          <div className="flex flex-wrap justify-center items-center gap-8 mb-12 text-sm">
            <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
              <Award className="w-4 h-4 text-orange-400" />
              <span>Licensed & Insured</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
              <Award className="w-4 h-4 text-orange-400" />
              <span>15+ Years Experience</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full">
              <Award className="w-4 h-4 text-orange-400" />
              <span>Code Compliant</span>
            </div>
          </div>
          
          {/* Main CTA Content */}
          <h2 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Ready to Create Your
            <span className="block luxury-text">Dream Theater?</span>
          </h2>
          
          <p className="text-xl md:text-2xl mb-12 leading-relaxed max-w-3xl mx-auto text-gray-200">
            Join hundreds of satisfied Potomac homeowners who trust us with their luxury entertainment spaces. 
            Professional consultation, custom design, and lifetime support.
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
            <a 
              href="tel:+13015550123" 
              className="bg-orange-500 hover:bg-orange-600 text-white px-10 py-5 rounded-xl font-bold text-xl transition-all duration-300 flex items-center space-x-3 shadow-2xl hover:shadow-orange-500/25 transform hover:scale-105 group"
            >
              <Phone size={24} className="group-hover:animate-pulse" />
              <span>Call Now: (301) 555-0123</span>
            </a>
            
            <button className="border-2 border-white/70 hover:border-white text-white hover:bg-white/10 px-10 py-5 rounded-xl font-bold text-xl transition-all duration-300 flex items-center space-x-3 backdrop-blur-sm group">
              <Calendar size={24} className="group-hover:rotate-12 transition-transform" />
              <span>Schedule Consultation</span>
            </button>
          </div>
          
          {/* Contact Information */}
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Phone className="w-8 h-8 text-orange-400 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Phone Consultation</h3>
              <p className="text-gray-300 text-sm mb-3">Speak with a licensed installer</p>
              <a href="tel:+13015550123" className="luxury-accent hover:text-orange-400 transition-colors">
                (301) 555-0123
              </a>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Mail className="w-8 h-8 text-orange-400 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Email Inquiry</h3>
              <p className="text-gray-300 text-sm mb-3">Detailed project discussion</p>
              <a href="mailto:info@potomactheater.com" className="luxury-accent hover:text-orange-400 transition-colors">
                info@potomactheater.com
              </a>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Calendar className="w-8 h-8 text-orange-400 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">In-Home Visit</h3>
              <p className="text-gray-300 text-sm mb-3">Free on-site consultation</p>
              <span className="luxury-accent">
                Available 7 Days/Week
              </span>
            </div>
          </div>
          
          {/* Service Area */}
          <div className="mt-12 text-center">
            <p className="text-gray-300">
              Proudly serving Potomac, Bethesda, McLean, Great Falls, and the greater DC metro area
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;