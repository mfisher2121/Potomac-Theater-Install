import React from 'react';
import { Award, Users, Clock, MapPin } from 'lucide-react';

const AboutSection = () => {
  const stats = [
    {
      icon: Clock,
      number: '15+',
      label: 'Years Experience'
    },
    {
      icon: Users,
      number: '500+',
      label: 'Happy Clients'
    },
    {
      icon: Award,
      number: '50+',
      label: 'Industry Awards'
    },
    {
      icon: MapPin,
      number: '5',
      label: 'States Served'
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Creating <span className="text-orange-500">Extraordinary</span> Experiences
            </h2>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              For over 15 years, Potomac Theater Installers has been the premier choice for luxury home theater installations 
              throughout the Mid-Atlantic region. Our passion for cinematic excellence drives every project we undertake.
            </p>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center mt-1">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Expert Craftsmanship</h3>
                  <p className="text-gray-600">Our certified technicians bring decades of combined experience to every installation.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center mt-1">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Premium Partnerships</h3>
                  <p className="text-gray-600">Authorized dealer for the world's leading audio and video equipment manufacturers.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center mt-1">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Lifetime Support</h3>
                  <p className="text-gray-600">Comprehensive warranty and ongoing support to ensure your system performs flawlessly.</p>
                </div>
              </div>
            </div>
            
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105">
              Learn More About Us
            </button>
          </div>
          
          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-8">
            {stats.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <div key={index} className="text-center p-8 bg-gray-50 rounded-xl hover:bg-orange-50 transition-colors duration-300 group">
                  <div className="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:bg-orange-500 transition-colors duration-300">
                    <IconComponent className="w-8 h-8 text-orange-500 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                  <div className="text-gray-600 font-medium">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;