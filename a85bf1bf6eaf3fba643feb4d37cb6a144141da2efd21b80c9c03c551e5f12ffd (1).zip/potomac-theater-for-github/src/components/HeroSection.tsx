import React from 'react';

const HeroSection = () => {
  return (
    <section id="home" className="hero-media min-h-screen relative overflow-hidden">
      {/* Responsive Hero Image */}
      <picture className="absolute inset-0 w-full h-full">
        <source
          media="(min-width: 1024px)"
          srcSet="/images/hero_desktop.avif"
          type="image/avif"
        />
        <source
          media="(min-width: 1024px)"
          srcSet="/images/hero_desktop.webp"
          type="image/webp"
        />
        <source
          media="(max-width: 1023px)"
          srcSet="/images/hero_mobile.avif"
          type="image/avif"
        />
        <source
          media="(max-width: 1023px)"
          srcSet="/images/hero_mobile.webp"
          type="image/webp"
        />
        {/* Fallback */}
        <img
          src="/images/hero_desktop.webp"
          alt="Luxury home theater with custom leather seating, premium projection screen, and elegant bar area - Potomac Theater Installers"
          className="w-full h-full object-cover"
        />
      </picture>
      
      {/* Gradient Overlay - User's exact specification */}
      <div className="overlay"></div>
      
      {/* Content Container */}
      <div className="relative z-10 h-full flex flex-col">
        {/* Tagline - User's exact positioning and styling */}
        <div className="tagline">
          Luxury You Can Sink Into.
          
          {/* Verification Badges - User's exact specification */}
          <ul className="badges">
            <li>Directory Verified</li>
            <li>Locally Verified</li>
            <li>Installer Verified</li>
          </ul>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/70 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/50 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;