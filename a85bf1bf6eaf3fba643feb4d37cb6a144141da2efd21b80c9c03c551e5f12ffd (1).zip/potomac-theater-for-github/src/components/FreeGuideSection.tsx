import React from 'react';
import { Download, FileText, Star } from 'lucide-react';

const FreeGuideSection = () => {
  return (
    <section id="guide" className="py-20 bg-white relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <picture>
          <source
            srcSet="/images/guide.avif"
            type="image/avif"
          />
          <img
            src="/images/guide.webp"
            alt="Luxury home theater guide background"
            className="w-full h-full object-cover opacity-10"
          />
        </picture>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Free Guide Card */}
          <div className="figure bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden">
            {/* Free Ribbon - User's exact styling */}
            <div className="free-ribbon">Free PDF</div>
            
            <div className="grid md:grid-cols-2 gap-8 p-8 md:p-12">
              {/* Guide Image */}
              <div className="relative">
                <picture>
                  <source
                    srcSet="/images/guide.avif"
                    type="image/avif"
                  />
                  <img
                    src="/images/guide.webp"
                    alt="Ultimate Home Theater Planning Guide - Free PDF from Potomac Theater Installers"
                    className="w-full rounded-xl shadow-lg"
                  />
                </picture>
                
                {/* Guide Badge */}
                <div className="absolute -top-4 -right-4 bg-orange-500 text-white p-3 rounded-full shadow-lg">
                  <FileText size={24} />
                </div>
              </div>
              
              {/* Guide Content */}
              <div className="flex flex-col justify-center">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                  Ultimate Home Theater <span className="luxury-accent">Planning Guide</span>
                </h2>
                
                <p className="text-xl text-gray-600 mb-6 leading-relaxed">
                  Everything you need to know before starting your home theater project. 
                  Written by licensed professionals with 15+ years of experience.
                </p>
                
                {/* Guide Features */}
                <div className="space-y-4 mb-8">
                  <div className="flex items-start space-x-3">
                    <Star className="w-5 h-5 text-orange-500 mt-1" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Room Planning & Layout</h4>
                      <p className="text-gray-600 text-sm">Optimal dimensions, seating arrangements, and viewing angles</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <Star className="w-5 h-5 text-orange-500 mt-1" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Budget Planning</h4>
                      <p className="text-gray-600 text-sm">Realistic cost breakdowns from basic to luxury installations</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <Star className="w-5 h-5 text-orange-500 mt-1" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Technology Guide</h4>
                      <p className="text-gray-600 text-sm">Latest projectors, audio systems, and smart home integration</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <Star className="w-5 h-5 text-orange-500 mt-1" />
                    <div>
                      <h4 className="font-semibold text-gray-900">Code Compliance</h4>
                      <p className="text-gray-600 text-sm">Local requirements and permit guidelines for Potomac area</p>
                    </div>
                  </div>
                </div>
                
                {/* Download Button */}
                <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 flex items-center justify-center space-x-3 shadow-lg hover:shadow-xl transform hover:scale-105 group">
                  <Download size={20} className="group-hover:animate-bounce" />
                  <span>Download Free Guide</span>
                </button>
                
                <p className="text-sm text-gray-500 mt-4 text-center">
                  No email required • Instant download • 24 pages
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FreeGuideSection;