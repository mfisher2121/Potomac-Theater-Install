import React from 'react';
import { ArrowRight } from 'lucide-react';

const ServicesSection = () => {
  const services = [
    {
      id: 'basement',
      title: 'Basement Conversion',
      label: 'Popular',
      description: 'Transform your basement into a luxurious home theater with custom seating, acoustic treatment, and premium finishes.',
      features: ['Custom Seating Design', 'Acoustic Optimization', 'Lighting Control', 'Climate Management']
    },
    {
      id: 'projector',
      title: 'Projector Installation',
      label: 'Premium',
      description: 'Professional installation of high-end projectors with precision mounting, calibration, and seamless integration.',
      features: ['4K/8K Projectors', 'Ceiling Mounting', 'Professional Calibration', 'Screen Integration']
    },
    {
      id: 'surround',
      title: 'Surround & Atmos',
      label: 'Advanced',
      description: 'Immersive audio systems with Dolby Atmos, premium speakers, and expert acoustic tuning for the ultimate experience.',
      features: ['Dolby Atmos Setup', 'Premium Speakers', 'Acoustic Tuning', 'Smart Integration']
    }
  ];

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Expert <span className="luxury-accent">Theater Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Licensed, code-compliant installations for discerning Potomac homeowners. 
            Apple-level precision meets luxury craftsmanship.
          </p>
        </div>
        
        {/* Services Grid - User's specification: 12 cols mobile, 4 cols each desktop */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service) => (
            <div key={service.id} className="group">
              {/* Service Card with Figure Label */}
              <div className="figure bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 group-hover:-translate-y-2">
                {/* Label - User's exact styling */}
                <div className="label">{service.label}</div>
                
                {/* Service Image */}
                <div className="relative h-64 overflow-hidden">
                  <picture>
                    <source
                      srcSet={`/images/service_${service.id}.avif`}
                      type="image/avif"
                    />
                    <img
                      src={`/images/service_${service.id}.webp`}
                      alt={`${service.title} - Luxury home theater service by Potomac Theater Installers`}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                  </picture>
                </div>
                
                {/* Service Content */}
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-orange-500 transition-colors duration-300">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {service.description}
                  </p>
                  
                  {/* Features List */}
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm text-gray-600">
                        <div className="w-1.5 h-1.5 bg-orange-400 rounded-full mr-3"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  {/* CTA Button */}
                  <button className="w-full bg-gray-900 hover:bg-orange-500 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2 group-hover:shadow-xl">
                    <span>Learn More</span>
                    <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Ready to Create Your Dream Theater?
          </h3>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Licensed professionals serving Potomac and the greater DC metro area. 
            Code-compliant installations with lifetime support.
          </p>
          <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105">
            Schedule Free Consultation
          </button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;